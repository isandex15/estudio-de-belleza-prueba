import json
import os
from datetime import date

from locust import HttpUser, between, task


# Estos datos son los de una cuenta de prueba. Se leen del entorno para no
# guardar contraseñas en el archivo.
CEDULA = os.getenv("LOCUST_CEDULA", "4723317").strip()
PASSWORD = os.getenv("LOCUST_PASSWORD", "admin123").strip()

# En login.py, el CAPTCHA de prueba usa este código cuando app.testing=True.
CAPTCHA_CODE = "AB12CD"

# Datos de ejemplo: reemplaza estos códigos por un proveedor y producto
# existentes en tu base de datos de pruebas.
COD_PROVEEDOR = 2
COD_PRODUCTO = 7
CANTIDAD = 1
PRECIO = 10.00


def leer_json(response, operacion):
    try:
        return response.json()
    except ValueError as error:
        raise RuntimeError(
            f"{operacion}: HTTP {response.status_code}, "
            f"Content-Type {response.headers.get('Content-Type', 'desconocido')}, "
            f"respuesta {response.text[:200]!r}"
        ) from error


class Compra(HttpUser):
    # Pausa aleatoria entre tareas de este usuario virtual (en segundos).
    wait_time = between(1, 5)

    def on_start(self):
        # Locust conserva las cookies de self.client entre peticiones;
        # así se conserva la sesión después de iniciar sesión.
        if not CEDULA or not PASSWORD:
            raise RuntimeError("Define LOCUST_CEDULA y LOCUST_PASSWORD.")

        url_login = "/admin?ruta=login"

        generar = self.client.post(
            url_login,
            data={"generar_captcha": "1"},
        )
        if not leer_json(generar, "Generar CAPTCHA").get("status"):
            raise RuntimeError("No se pudo generar el CAPTCHA de prueba.")

        captcha = self.client.post(
            url_login,
            data={
                "verificar_captcha": "1",
                "respuesta": CAPTCHA_CODE,
            },
        )
        if not leer_json(captcha, "Verificar CAPTCHA").get("verificado"):
            raise RuntimeError(
                "No se verificó el CAPTCHA. Usa app.testing=True para la prueba."
            )

        login = self.client.post(
            url_login,
            data={
                "login": "1",
                "cedula": CEDULA,
                "password": PASSWORD,
            },
        )
        resultado_login = leer_json(login, "Iniciar sesión")
        if resultado_login.get("icon") != "success":
            raise RuntimeError(
                resultado_login.get("text", "No se pudo iniciar sesión.")
            )

    @task
    def registrar_compra(self):
        # El controlador espera estos campos del formulario. "productos" es
        # una lista convertida a JSON porque el servidor la lee con json.loads.
        datos = {
            "registrar": "1",
            "fecha_compra": date.today().isoformat(),
            "cod_proveedor": str(COD_PROVEEDOR),
            "total": str(CANTIDAD * PRECIO),
            "productos": json.dumps(
                [
                    {
                        "cod_producto": COD_PRODUCTO,
                        "cantidad": CANTIDAD,
                        "precio": PRECIO,
                    }
                ]
            ),
        }

        with self.client.post(
            "/admin?ruta=compra",
            data=datos,
            name="Registrar compra",
            catch_response=True,
        ) as response:
            try:
                resultado = response.json()
            except ValueError:
                response.failure(
                    f"El servidor no devolvió JSON: HTTP {response.status_code}, "
                    f"respuesta {response.text[:200]!r}"
                )
                return

            if response.status_code == 200 and resultado.get("icon") == "success":
                response.success()
            else:
                response.failure(
                    resultado.get("text", f"Error HTTP {response.status_code}")
                )
